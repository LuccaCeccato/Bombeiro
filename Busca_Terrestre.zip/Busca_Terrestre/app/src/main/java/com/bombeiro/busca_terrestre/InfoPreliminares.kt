package com.bombeiro.busca_terrestre

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bombeiro.busca_terrestre.databinding.ActivityInfoPreliminaresBinding

class InfoPreliminares : AppCompatActivity() {

    private lateinit var binding: ActivityInfoPreliminaresBinding
    private var isComplementoExpanded = false
    private var isInfoExpanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityInfoPreliminaresBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Listener para a seta que expande/contrai o layout de informações complementares
        binding.imageView4.setOnClickListener {
            toggleInfoLayout()
        }

        // Listener para a seta que expande/contrai o layout de funções
        binding.imageView5.setOnClickListener {
            toggleComplementoLayout()
        }

        // Listener para o botão voltar
        binding.textViewVoltarTela.setOnClickListener {
            startActivity(Intent(this, GuiaOperacionalTeoria::class.java))
        }

        // Ajusta padding para considerar insets do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Método para alternar o layout de funções (Coleta de Informações Preliminares)
    private fun toggleInfoLayout() {
        if (isInfoExpanded) {
            binding.scrollViewColetaInfoPreliminares.visibility = View.GONE
            binding.imageView5.setImageResource(R.drawable.pngwing_com) // Seta para baixo
        } else {
            binding.scrollViewColetaInfoPreliminares.visibility = View.VISIBLE
            binding.imageView5.setImageResource(R.drawable.pngwing_com) // Seta para cima
        }
        isInfoExpanded = !isInfoExpanded
    }

    // Método para alternar o layout de informações complementares
    private fun toggleComplementoLayout() {
        if (isComplementoExpanded) {
            binding.scrollViewComplementoInfo.visibility = View.GONE
            binding.imageView4.setImageResource(R.drawable.pngwing_com) // Seta para baixo
        } else {
            binding.scrollViewComplementoInfo.visibility = View.VISIBLE
            binding.imageView4.setImageResource(R.drawable.pngwing_com) // Seta para cima
        }
        isComplementoExpanded = !isComplementoExpanded
    }
}
