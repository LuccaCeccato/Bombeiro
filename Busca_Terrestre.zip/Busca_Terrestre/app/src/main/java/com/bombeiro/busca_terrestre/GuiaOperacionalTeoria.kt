package com.bombeiro.busca_terrestre

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bombeiro.busca_terrestre.databinding.ActivityGuiaOperacionalTeoriaBinding

class GuiaOperacionalTeoria : AppCompatActivity() {

    private lateinit var binding: ActivityGuiaOperacionalTeoriaBinding
    private var isExpanded = false
    private var isFuncoesExpanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicialização do ViewBinding
        binding = ActivityGuiaOperacionalTeoriaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ajuste das margens de acordo com os system bars
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Listener para a seta
        binding.imageView4.setOnClickListener {
            toggleExpandableLayout()
        }

        binding.viewFuncoes.setOnClickListener {
            toggleFuncoesLayout()
        }

        binding.layoutBotaoAvancar.setOnClickListener {
            val intent = Intent(this, InfoPreliminares::class.java)
            startActivity(intent) // Iniciar a nova Activity
        }



    }




    private fun toggleFuncoesLayout() {
        if (isFuncoesExpanded) {
            // Esconder o layout expansível de Funções da Operação
            binding.scrollViewFuncoes.visibility = View.GONE
            binding.imageView5.setImageResource(R.drawable.pngwing_com) // Seta para baixo
            binding.imageViewComandante.visibility = View.GONE  // Esconder a imagem de Funções
            binding.imageViewLogistica.visibility = View.GONE
            binding.imageViewNavegador.visibility = View.GONE
            binding.imageViewResgatista.visibility = View.GONE
        } else {
            // Mostrar o layout expansível de Funções da Operação
            binding.scrollViewFuncoes.visibility = View.VISIBLE
            binding.imageView5.setImageResource(R.drawable.pngwing_com) // Seta para cima
            binding.imageViewComandante.visibility = View.VISIBLE  // Mostrar a imagem de Funções
            binding.imageViewLogistica.visibility = View.VISIBLE
            binding.imageViewNavegador.visibility = View.VISIBLE
            binding.imageViewResgatista.visibility = View.VISIBLE
        }
        isFuncoesExpanded = !isFuncoesExpanded
    }


    private fun toggleExpandableLayout() {
        if (isExpanded) {
            // Esconder o layout expansível
            binding.scrollView.visibility = View.GONE
            binding.imageView4.setImageResource(R.drawable.pngwing_com)  // Seta para baixo
            binding.imageViewFases.visibility = View.GONE  // Esconder a imagem
        } else {
            // Mostrar o layout expansível
            binding.scrollView.visibility = View.VISIBLE
            binding.imageView4.setImageResource(R.drawable.pngwing_com)  // Seta para cima
            binding.imageViewFases.visibility = View.VISIBLE  // Mostrar a imagem
        }
        isExpanded = !isExpanded
    }

}
